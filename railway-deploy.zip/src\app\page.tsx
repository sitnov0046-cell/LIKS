'use client';

import { useEffect, useState } from 'react';
import { useTelegramWebApp } from '@/hooks/useTelegramWebApp';

export default function Home() {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const { webApp, isReady } = useTelegramWebApp();

  useEffect(() => {
    if (isReady && webApp) {
      webApp.MainButton.text = 'Сгенерировать видео';
      webApp.MainButton.onClick(() => handleGenerate());
      webApp.expand();
    }
  }, [isReady, prompt]);

  const handleGenerate = async () => {
    if (!prompt || isGenerating) return;

    setIsGenerating(true);
    try {
      // TODO: Здесь будет логика генерации видео
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert('Видео генерируется! Мы уведомим вас, когда оно будет готово.');
    } catch (error) {
      alert('Произошла ошибка при генерации видео');
    } finally {
      setIsGenerating(false);
    }
  };

  const updatePrompt = (newPrompt: string) => {
    setPrompt(newPrompt);
    if (webApp && isReady) {
      if (newPrompt.trim()) {
        webApp.MainButton.show();
      } else {
        webApp.MainButton.hide();
      }
    }
  };

  return (
    <main className="flex min-h-screen flex-col items-center p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Генерация видео</h1>
      
      <div className="w-full space-y-4">
        <div className="space-y-2">
          <label className="block text-sm font-medium">
            Опишите видео, которое хотите создать:
          </label>
          <textarea
            className="w-full p-3 border rounded-lg shadow-sm focus:ring-2 focus:ring-telegram focus:border-transparent"
            rows={4}
            placeholder="Например: Закат на пляже с пальмами и волнами..."
            value={prompt}
            onChange={(e) => updatePrompt(e.target.value)}
            disabled={isGenerating}
          />
        </div>

        {isGenerating && (
          <div className="text-center py-4">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-telegram border-t-transparent"></div>
            <p className="mt-2 text-sm text-gray-600">Генерация видео...</p>
          </div>
        )}
      </div>
    </main>
  );
}