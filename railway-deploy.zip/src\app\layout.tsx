import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Video Generator',
  description: 'Generate videos from text using AI',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ru">
      <head>
        <script src="https://telegram.org/js/telegram-web-app.js"></script>
      </head>
      <body>{children}</body>
    </html>
  );
}